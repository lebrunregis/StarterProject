Hair Presets must be copy and pasted to a specific location to show up in VROID STUDIO!!! They *MUST* be there or you can't import them.


1) Copy the Hair Preset Folder (whole folder, not the contents)

2) Navigate to C:\Users\YourName\AppData\LocalLow\pixiv\VRoidStudio\hair_presets

3) Paste the Hair Preset Folder there (the whole folder, not the contents)

4) The Hair Preset should appear in VRoid Studio under Hair Editor. There is a dropdown list of all Hair Presets.

IMPORTANT: Importing a Hair Preset REMOVES EXISTING HAIR. 
If you have existing Hair on your Vroid, export it so you can bring it back later if you need it.

